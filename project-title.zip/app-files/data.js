var APP_DATA = {
  "scenes": [
    {
      "id": "0-m1",
      "name": "m1",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        }
      ],
      "faceSize": 1024,
      "initialViewParameters": {
        "yaw": -2.7875947200799747,
        "pitch": 0,
        "fov": 1.3237681912121593
      },
      "linkHotspots": [
        {
          "yaw": -2.794714199714747,
          "pitch": -0.02829088329406737,
          "rotation": 0,
          "target": "1-m2"
        }
      ],
      "infoHotspots": [
        {
          "yaw": -2.786754223379928,
          "pitch": 0,
          "title": "Title",
          "text": "Text"
        }
      ]
    },
    {
      "id": "1-m2",
      "name": "m2",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 2048,
      "initialViewParameters": {
        "pitch": 0,
        "yaw": 0,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [
        {
          "yaw": 0,
          "pitch": 0,
          "rotation": 0,
          "target": "2-m3"
        }
      ],
      "infoHotspots": []
    },
    {
      "id": "2-m3",
      "name": "m3",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        }
      ],
      "faceSize": 1024,
      "initialViewParameters": {
        "pitch": 0,
        "yaw": 0,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [
        {
          "yaw": 0.0018450350000733806,
          "pitch": 0,
          "rotation": 0,
          "target": "3-m4"
        }
      ],
      "infoHotspots": []
    },
    {
      "id": "3-m4",
      "name": "m4",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        }
      ],
      "faceSize": 1024,
      "initialViewParameters": {
        "yaw": 0.0023272451000035943,
        "pitch": 0,
        "fov": 1.3237681912121593
      },
      "linkHotspots": [
        {
          "yaw": 0,
          "pitch": 0,
          "rotation": 0,
          "target": "0-m1"
        }
      ],
      "infoHotspots": []
    }
  ],
  "name": "Project Title",
  "settings": {
    "mouseViewMode": "drag",
    "autorotateEnabled": true,
    "fullscreenButton": true,
    "viewControlButtons": true
  }
};
